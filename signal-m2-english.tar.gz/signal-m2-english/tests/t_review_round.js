/* Os ajustes vindos da reunião com a Elaine · 15/09/2026
   Cada bloco roda numa página limpa: o app guarda estado no navegador. */
const { chromium, devices } = require('playwright');
const path = require('path');
let ok=0, falha=0; const T=(n,c)=>{ if(c) ok++; else { falha++; console.log('FALHA:',n); } };
const ARQ = process.argv[2] || '/home/claude/w/signal_m2.html';
(async()=>{
  const b = await chromium.launch();
  const erros = [];
  const nova = async () => {
    const p = await (await b.newContext({ ...devices['iPhone 13'] })).newPage();
    p.on('pageerror', e => erros.push(e.message.slice(0,140)));
    await p.goto('file://'+path.resolve(ARQ), {waitUntil:'load'});
    await p.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
    await p.reload({waitUntil:'load'});
    await p.waitForTimeout(700);
    return p;
  };

  /* ---- A1 e B1 · a retomada ---- */
  {
    const p = await nova();
    const r = await p.evaluate(async () => {
      const w=ms=>new Promise(r=>setTimeout(r,ms));
      const o={};
      S._boot=false; S.perfil={relacao:2,cargo:2,tamanho:3};
      QUESTIONS.forEach(q=>S.respostas[q.id]=40);
      S.result=calcular(); S.pago=true; liberaConta();
      const faixa = () => { ir('sinal'); const el=document.querySelector('.retoma'); return el?el.innerText.replace(/\n/g,' '):''; };
      /* separação começada */
      const ks = pilaresSeparar(S.result);
      S.sep[ks[0]] = {0:1,1:1,2:1};
      o.naSeparacao = faixa();
      /* separação feita, diário começado */
      ks.forEach(k=>S.sep[k]={0:1,1:1,2:1});
      const qs = todasPerguntas(S.result);
      S.diario[qs[0].q.id]='r';
      o.noDiario = faixa();
      /* diário completo, falta a resposta */
      qs.forEach(x=>S.diario[x.q.id]='r');
      o.naResposta = faixa();
      /* respondeu, mas pulou o somar */
      S.respondido=true; S.resposta='x'; S.somarPulado=true;
      o.semSomar = faixa();
      o.pulsosTrancado = !MENUS.find(m=>m.r==='pulsos').livre();
      /* o menu trancado dá o caminho */
      await w(200);
      const mn = Array.from(document.querySelectorAll('[data-a="trancado"]')).find(x=>x.textContent.indexOf('Pulses')>-1);
      if(mn) mn.click(); await w(400);
      o.modalDoPulsos = (document.getElementById('modal')||{}).innerText || '';
      o.temBotaoSomar = !!document.querySelector('#modal [data-v="somar"]');
      /* somou: a faixa some */
      S.somado='acme|BR';
      o.depoisDeSomar = faixa();
      return o;
    });
    T('a faixa aponta a separação ("'+r.naSeparacao.slice(0,52)+'")', r.naSeparacao.indexOf('separation') > -1);
    T('depois o diário ("'+r.noDiario.slice(0,44)+'")', r.noDiario.indexOf('journal') > -1);
    T('depois a resposta ("'+r.naResposta.slice(0,44)+'")', r.naResposta.indexOf('your answer') > -1);
    T('e o sinal não somado ("'+r.semSomar.slice(0,52)+'")', r.semSomar.indexOf('not been added') > -1 && r.pulsosTrancado);
    T('o menu trancado oferece somar, em vez de só avisar', r.temBotaoSomar && r.modalDoPulsos.toLowerCase().indexOf('add your signal') > -1);
    T('somado, a faixa desaparece', r.depoisDeSomar === '');
    
  }

  /* ---- C · país no sinal, pulsos e vozes ---- */
  {
    const p = await nova();
    const r = await p.evaluate(async () => {
      const w=ms=>new Promise(r=>setTimeout(r,ms));
      const o={};
      o.paises = PAISES.length;
      o.temDDIeBandeira = PAISES.every(x => x.d && x.f && x.c && x.s);
      S._boot=false; S.perfil={relacao:2,cargo:2,tamanho:3};
      QUESTIONS.forEach(q=>S.respostas[q.id]=40);
      S.result=calcular(); S.pago=true; liberaConta(); S.acoes=['x'];
      /* C1 · o somar exige país */
      ir('somar'); await w(300);
      S.empresa='ACME'; S.empresaK=chaveEmp('ACME'); render({mantem:true}); await w(300);
      o.temSeletor = !!document.querySelector('[data-a="abrirPaisSinal"]');
      o.somarBloqueado = !document.querySelector('[data-a="somarSinal"]');
      A.somarSinal(); await w(200);
      o.naoSomouSemPais = !S.somado;
      /* escolhe o país */
      A.abrirPaisSinal(); await w(300);
      o.listaPaises = document.querySelectorAll('#modal .pais__i').length;
      o.temBandeiraNaLista = (document.querySelector('#modal .pais__f')||{}).textContent || '';
      const br = Array.from(document.querySelectorAll('#modal .pais__i')).find(x=>x.textContent.indexOf('Brazil')>-1);
      if(br) br.click(); await w(400);
      o.paisEscolhido = S.paisSinal;
      o.somarLiberado = !!document.querySelector('[data-a="somarSinal"]');
      A.somarSinal(); await w(300);
      o.somou = !!S.somado;
      /* C1b · a bandeira no seletor dos pulsos */
      S.somado='acme|BR'; liberaConta(); ir('pulsos'); await w(400);
      A.abrirPaisesPulso(); await w(300);
      o.pulsosComBandeira = !!document.querySelector('#modal .pais__f');
      fechaModal(); await w(200);
      /* C2 · propor assunto pede país */
      ir('vozes'); await w(300);
      A.proporAssunto(); await w(300);
      o.assuntoTemPais = !!document.querySelector('#modal [data-a="abrirPaisAssunto"]');
      const ta = document.getElementById('vaTx'); if(ta) ta.value = 'Camada de gestão inchada';
      A.enviarAssunto(); await w(200);
      o.barrouSemPais = !!document.getElementById('modal').classList.contains('on');
      A.abrirPaisAssunto(); await w(300);
      const pt = Array.from(document.querySelectorAll('#modal .pais__i')).find(x=>x.textContent.indexOf('Portugal')>-1);
      if(pt) pt.click(); await w(300);
      o.paisAssunto = S.paisAssunto;
      return o;
    });
    T('a base tem '+r.paises+' países, com sigla, DDI, bandeira e continente', r.paises >= 30 && r.temDDIeBandeira);
    T('o somar mostra o seletor e não deixa somar sem país', r.temSeletor && r.somarBloqueado && r.naoSomouSemPais);
    T('a lista abre por continente, com bandeira ('+r.listaPaises+' países, '+r.temBandeiraNaLista+')',
      r.listaPaises >= 30 && r.temBandeiraNaLista.length > 0);
    T('escolhido o país, o somar libera e soma ('+r.paisEscolhido+')',
      r.paisEscolhido === 'Brazil' && r.somarLiberado && r.somou);
    T('o seletor dos Pulsos ganhou bandeira', r.pulsosComBandeira);
    T('propor assunto pede o país e barra sem ele', r.assuntoTemPais && r.barrouSemPais);
    T('e o país do assunto é registrado ('+r.paisAssunto+')', r.paisAssunto === 'Portugal');
    
  }

  /* ---- E · a conta e as assinaturas ---- */
  {
    const p = await nova();
    const r = await p.evaluate(async () => {
      const w=ms=>new Promise(r=>setTimeout(r,ms));
      const o={};
      S._boot=false; S.perfil={relacao:2,cargo:2,tamanho:3};
      QUESTIONS.forEach(q=>S.respostas[q.id]=40);
      S.result=calcular(); S.email='x@y.com'; S.pago=true; liberaConta();
      ir('conta'); await w(500);
      const txt = document.body.innerText;
      o.semJornada = txt.indexOf('Jornada') === -1;
      o.semExportar = txt.indexOf('Exportar') === -1;
      o.anonimatoEhAtalho = !!Array.from(document.querySelectorAll('button')).find(x=>x.textContent==='Read');
      o.temEncerrar = txt.indexOf('Close the account') > -1;
      /* E4 · a tela de assinaturas */
      S.menuConta = true; render(); await w(300);
      const it = Array.from(document.querySelectorAll('.mc__t')).map(x=>x.textContent);
      o.menuItens = it;
      const bt = Array.from(document.querySelectorAll('.mc__i')).find(x=>x.textContent.indexOf('Subscriptions')>-1);
      if(bt) bt.click(); await w(500);
      o.rota = S.rota;
      o.planos = Array.from(document.querySelectorAll('.pl2__n')).map(x=>x.textContent);
      o.temVigencia = document.body.innerText.indexOf('No subscription renews itself') > -1;
      /* E5 · a confirmação */
      document.querySelector('[data-a="assinar"][data-v="mensal"]').click(); await w(400);
      o.modal = (document.getElementById('modal')||{}).innerText || '';
      o.pedeConfirmacao = o.modal.indexOf('Subscribe to the Monthly plan?') > -1 && !!document.querySelector('[data-a="assinarOk"]');
      o.naoAssinouAinda = S.plano !== 'mensal';
      document.querySelector('[data-a="assinarOk"]').click(); await w(800);
      o.assinou = S.plano;
      /* o modal fecha e a tela é redesenhada: medir a tela, não o que restou dele */
      ir('assinatura'); await w(400);
      o.marcaAtual = !!document.querySelector('.pl2--on .pl2__atual');
      return o;
    });
    T('E1 · a jornada saiu da conta', r.semJornada);
    T('E3 · exportar os dados saiu, e encerrar a conta ficou', r.semExportar && r.temEncerrar);
    T('E2 · o anonimato virou atalho para os termos', r.anonimatoEhAtalho);
    T('E4 · o menu leva a Assinaturas ('+r.menuItens.join(' · ')+')', r.rota === 'assinatura');
    T('E4 · com os três planos ('+r.planos.join(' · ')+') e a vigência', r.planos.length === 3 && r.temVigencia);
    T('E5 · assinar pede confirmação antes ('+r.modal.slice(0,40).replace(/\n/g,' ')+')', r.pedeConfirmacao && r.naoAssinouAinda);
    T('E5 · e confirmando, a assinatura fica marcada ('+r.assinou+')', r.assinou === 'mensal' && r.marcaAtual);
    
  }

  /* ---- B3 e F1 · onde estou ---- */
  {
    const p = await nova();
    const r = await p.evaluate(async () => {
      const w=ms=>new Promise(r=>setTimeout(r,ms));
      const o={};
      S._boot=false; S.perfil={relacao:2,cargo:2,tamanho:3};
      QUESTIONS.forEach(q=>S.respostas[q.id]=40);
      S.result=calcular(); S.pago=true; liberaConta();
      S.somado='x'; S.respondido=true; liberaConta();
      /* o selo do assistente entra no innerText; o nome do menu é o último pedaço */
      const abaAcesa = () => { const el=document.querySelector('.tb.on');
        return el ? el.innerText.trim().split('\n').pop().trim() : ''; };
      ir('resposta'); await w(400);
      o.resposta = { aba:abaAcesa(), faixa:(document.querySelector('.onde')||{}).innerText||'' };
      ir('somar'); await w(300); o.somar = abaAcesa();
      ir('minhaEmpresa'); await w(300); o.minhaEmpresa = abaAcesa();
      ir('assinatura'); await w(300); o.assinatura = abaAcesa();
      ir('pesquisa'); await w(300);
      o.pesquisaRotulo = (document.querySelector('.k--v')||{}).textContent;
      return o;
    });
    /* innerText devolve o texto já com o text-transform do CSS: comparar sem caixa */
    T('a resposta acende o Diário e diz onde está (aba "'+r.resposta.aba+'", faixa "'+r.resposta.faixa.replace(/\n/g,' ')+'")',
      r.resposta.aba === 'Journal' && r.resposta.faixa.toLowerCase().indexOf('journal') > -1);
    T('o somar acende o Sinal ('+r.somar+')', r.somar === 'Signal');
    T('minha empresa acende Pulsos ('+r.minhaEmpresa+')', r.minhaEmpresa === 'Pulses');
    T('assinaturas não acende menu de exercício ('+r.assinatura+')', r.assinatura !== 'Journal' && r.assinatura !== 'Signal');
    T('F1 · o rótulo da pesquisa mudou ('+r.pesquisaRotulo+')', r.pesquisaRotulo === 'Help us understand');
    
  }

  /* ---- A2 · o seletor de empresa ---- */
  {
    const p = await nova();
    const r = await p.evaluate(async () => {
      const w=ms=>new Promise(r=>setTimeout(r,ms));
      S._boot=false; S.perfil={relacao:2,cargo:2,tamanho:3};
      QUESTIONS.forEach(q=>S.respostas[q.id]=40);
      S.result=calcular(); S.pago=true; liberaConta();
      S.empresa='ACME'; S.empresaK=chaveEmp('ACME'); S.somado=S.empresaK;
      S.sinalId='s1'; S.criadoEm=Date.now(); liberaConta();
      /* um segundo sinal no histórico */
      S.sinais=[{id:'s2', empresa:'Aurora Health', empresaK:chaveEmp('Aurora Health'),
        criado:Date.now()-86400000, result:S.result, pago:true, somado:chaveEmp('Aurora Health'),
        perfil:S.perfil, respostas:S.respostas, sep:{}, acoes:[], diario:{}, resposta:''}];
      ir('minhaEmpresa'); await w(500);
      const antes = { empresa:S.empresa, sinalId:S.sinalId,
        botoes: Array.from(document.querySelectorAll('[data-a="trocarEmpresa"], [data-a="nada"]')).map(x=>({a:x.getAttribute('data-a'), v:x.getAttribute('data-v'), t:x.textContent.trim().slice(0,20)})) };
      /* clica no outro */
      const outro = document.querySelector('[data-a="trocarEmpresa"]');
      if(outro) outro.click(); await w(600);
      const depois = { empresa:S.empresa, sinalId:S.sinalId, rota:S.rota,
        tela: document.body.innerText.slice(0,160).replace(/\n/g,' · '),
        temPulso: !!PULSOS.find(e=>chaveEmp(e.n)===chaveEmp(S.empresa)),
        nos: document.querySelectorAll('#app .sec, #app .card, #app .pl').length };
      /* e o caso do Victor: empresa que não está na base de pulsos */
      S.empresa='Batatinha'; S.empresaK=chaveEmp('Batatinha'); S.somado=S.empresaK;
      ir('minhaEmpresa'); await w(500);
      const semPulso = { empresa:S.empresa,
        temPulso: !!PULSOS.find(e=>chaveEmp(e.n)===chaveEmp(S.empresa)),
        tela: document.body.innerText.slice(0,220).replace(/\n/g,' · '),
        nos: document.querySelectorAll('#app .sec, #app .card, #app .pl').length };
      return { antes, depois, semPulso };
    });
    console.log(JSON.stringify(r,null,1));
    
  }

  console.log('\n===== reunião com a Elaine: '+ok+' ok, '+falha+' falhas · erros de página: '+(erros.length?erros.slice(0,3):'nenhum')+' =====');
  await b.close();
  process.exit(falha ? 1 : 0);
})().catch(e => { console.error('ERRO:', e.message); process.exit(1); });
