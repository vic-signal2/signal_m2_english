/* Os 21 ajustes do build M2 · 15/09/2026
   Cada bloco roda numa página nova: o estado do app é global e não convém
   compartilhar entre cenários. */
const { chromium, devices } = require('playwright');
const path = require('path');
let ok=0, falha=0; const T=(n,c)=>{ if(c) ok++; else { falha++; console.log('FALHA:',n); } };
const ARQ = process.argv[2] || '/home/claude/w/signal_m2.html';
(async()=>{
  const b = await chromium.launch();
  const erros = [];
  const nova = async () => {
    const p = await (await b.newContext({ ...devices['iPhone 13'] })).newPage();
    p.on('pageerror', e => erros.push(e.message.slice(0,140)));
    await p.goto('file://'+path.resolve(ARQ), {waitUntil:'load'});
    /* o app guarda estado no navegador: cada bloco precisa de página limpa */
    await p.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
    await p.reload({waitUntil:'load'});
    await p.waitForTimeout(700);
    return p;
  };

  /* ---- bloco 1 ---- */
  {
    const p = await nova();
    const r = await p.evaluate(async () => {
      const w = ms => new Promise(r=>setTimeout(r,ms));
      const o = {};
      /* 1 · tempos da abertura */
      o.tempos = document.documentElement.innerHTML.indexOf('conv:[300,3300]') > -1;
      o.amanhece = document.documentElement.innerHTML.indexOf('2.35s forwards') > -1;
      /* 2 · botão da home */
      S._boot=false; ir('home'); await w(400);
      o.botaoHome = document.body.innerText.indexOf('Find my signal') > -1;
      /* 3 · foco só acima de 5.000 */
      o.foco4 = trilhaPerfil({relacao:2,cargo:2,tamanho:4}).indexOf('foco') > -1;
      o.foco5 = trilhaPerfil({relacao:2,cargo:2,tamanho:5}).indexOf('foco') > -1;
      /* 6 · itens do paywall */
      S.perfil={relacao:2,cargo:2,tamanho:3}; QUESTIONS.forEach(q=>S.respostas[q.id]=40);
      S.result=calcular(); S.email='x@y.com'; ir('sinal'); await w(600);
      const itens = Array.from(document.querySelectorAll('.veu__l li')).map(x=>x.textContent.trim());
      o.paywall = itens;
      o.paywallOk = itens[0].indexOf('Understanding what is within your reach') === 0 && itens[3].indexOf('Messages with the Signal Assistant') === 0;
      /* 7 · contador fora da caixa, mas presente no trilho */
      S.pago=true; ir('separar'); await w(600);
      o.semContadorNaCaixa = !document.querySelector('.alc__k b');
      o.contadorNoTrilho = document.body.innerText.indexOf('of 3 marked') > -1;
      /* o zoom é medido onde as opções existem: no questionário */
      ir('avaliar'); S.qi=0; render(); await w(400);
      o.zoom = getComputedStyle(document.querySelector('.opt')).touchAction;
      ir('separar'); await w(400);
      /* 8 e 9 · o somar */
      S.acoes=['a']; ir('somar'); await w(600);
      o.textoSomar = document.body.innerText.indexOf('Identify your company to join your signal') > -1;
      const rod = document.querySelector('.rodape2');
      o.margem = rod ? getComputedStyle(rod).marginTop : '';
      return o;
    });
    T('1 · a abertura encurtou', r.tempos && r.amanhece);
    T('2 · o botão da home mudou', r.botaoHome);
    T('3 · o foco só aparece acima de 5.000 (4:'+r.foco4+' 5:'+r.foco5+')', !r.foco4 && r.foco5);
    T('6 · a lista do paywall na ordem nova', r.paywallOk);
    T('7 · o contador saiu da caixa e ficou no trilho', r.semContadorNaCaixa && r.contadorNoTrilho);
    T('4 · o toque duplo não dá zoom nas opções ('+r.zoom+')', r.zoom === 'manipulation');
    T('8 · o texto do somar mudou', r.textoSomar);
    T('9 · os botões ganharam margem ('+r.margem+')', parseFloat(r.margem) >= 30);
    
  }

  /* ---- bloco 2 ---- */
  {
    const p = await nova();
    const r = await p.evaluate(async () => {
      const w = ms => new Promise(r=>setTimeout(r,ms));
      const o = {};
      S._boot=false; S.perfil={relacao:2,cargo:2,tamanho:3};
      QUESTIONS.forEach(q=>S.respostas[q.id]=40);
      S.result=calcular(); S.email='x@y.com'; S.pago=true; liberaConta();
      S.empresa='ACME'; S.empresaK='acme|BR'; S.somado='acme|BR'; liberaConta();
      S.sinalId='s1'; S.criadoEm=Date.now();
      /* 20 e 21 */
      o.foco = PERFIL.foco.t;
      o.focoOps = PERFIL.foco.o.map(x=>x.b);
      ir('avaliar'); S.qi=0; render(); await w(400);
      o.semNegrito = !document.querySelector('.opt b');
      /* 10 e 11 · a resposta leva à celebração e à pesquisa */
      todasPerguntas(S.result).forEach(q => S.diario[q.id] = 'resposta');
      ir('resposta'); await w(500);
      const ta = document.getElementById('rtx'); if(ta) ta.value = 'A minha resposta.';
      A.guardarResp(); await w(400);
      /* a celebração é uma camada sobre a tela, não uma rota */
      await w(600);
      o.celebra = !!document.querySelector('.cel');
      o.textoCelebra = ((document.querySelector('.cel')||{}).innerText||'').indexOf('reclaimed your voice') > -1;
      await w(2900);
      o.depois = S.rota;
      o.temEstrelas = document.querySelectorAll('.est').length;
      o.pergunta = document.body.innerText.indexOf('more clarity about where you are') > -1;
      /* dá nota e envia */
      document.querySelectorAll('.est')[3].click(); await w(300);
      o.nota = S.pesqNota;
      A.pesqEnviar(); await w(500);
      o.rotaFinal = S.rota;
      /* 18 · cria um sinal novo e os menus continuam abertos */
      o.antesDoNovo = MENUS.map(m=>m.livre());
      S.sinais = [{id:'s1', empresa:'ACME', criado:S.criadoEm, result:S.result, pago:true, somado:'acme|BR', resposta:'x'}];
      S.sinalId='s2'; S.criadoEm=Date.now(); S.result=null; S.pago=false; S.somado=null; S.respondido=false;
      S.perfil={}; S.respostas={}; S.diario={}; S.resposta='';
      o.depoisDoNovo = MENUS.map(m=>m.livre());
      /* 19 · o diário diz de qual sinal é */
      S.empresa=''; ir('diario'); await w(500);
      o.diarioExplica = document.body.innerText.indexOf('has not been assessed yet') > -1;
      o.temBarra = !!document.querySelector('.bsin');
      o.barraTexto = (document.querySelector('.bsin')||{}).innerText || '';
      return o;
    });
    T('20 · a pergunta de foco encurtou ('+r.foco+')', r.foco === 'Choose a focus for this assessment.');
    T('20 · e as alternativas mudaram ('+r.focoOps[0]+')', r.focoOps[0] === 'I will assess my local team, within my business unit.');
    T('21 · sem negrito nas alternativas de perfil', r.semNegrito);
    T('10 · a resposta abre a camada da celebração', r.celebra && r.textoCelebra);
    T('10 · que dura uns 2s e leva à pesquisa ('+r.depois+')', r.depois === 'pesquisa');
    T('11 · a pesquisa tem 5 estrelas e a pergunta certa ('+r.temEstrelas+')', r.temEstrelas === 5 && r.pergunta);
    T('11 · a nota é registrada e o envio leva à resposta ('+r.nota+' → '+r.rotaFinal+')', r.nota === 4 && r.rotaFinal === 'resposta');
    T('18 · os menus ficam abertos depois de criar outro sinal', r.depoisDoNovo.every(Boolean));
    T('19 · o diário explica em vez de mostrar vazio', r.diarioExplica);
    T('19 · e a barra diz de qual sinal é ('+r.barraTexto.replace(/\n/g,' ').slice(0,50)+')', r.temBarra);
    
  }

  /* ---- bloco 3 ---- */
  {
    const p = await nova();
    const r = await p.evaluate(async () => {
      const w = ms => new Promise(r=>setTimeout(r,ms));
      const o = {};
      S._boot=false; S.perfil={relacao:2,cargo:2,tamanho:3};
      QUESTIONS.forEach(q=>S.respostas[q.id]=40);
      S.result=calcular(); S.email='x@y.com'; S.pago=true; liberaConta();
      /* build de 15/09: Minha Empresa mostra o pulso só quando ele existe, em
         vez de cair no pulso de outra empresa. O teste usa uma da base. */
      S.empresa=PULSOS[0].n; S.empresaK=chaveEmp(PULSOS[0].n); S.somado=S.empresaK; liberaConta();
      /* 13 · vozes */
      ir('vozes'); await w(500);
      o.ressoar = document.body.innerText.indexOf('Tap to resonate') > -1;
      o.novidades = document.body.innerText.indexOf('Tap to receive updates') > -1;
      /* 14 · filtro de país */
      ir('pulsos'); await w(500);
      A.abrirRecorte(); await w(400);
      o.temEscolherPais = !!document.querySelector('[data-a="abrirPaisesPulso"]');
      o.filtros = Array.from(document.querySelectorAll('.rec__o button')).slice(0,3).map(x=>x.textContent);
      A.abrirPaisesPulso(); await w(400);
      o.paisesListados = document.querySelectorAll('.pais__i').length;
      const alvo = document.querySelector('.pais__i');
      const nomePais = alvo ? alvo.childNodes[0].textContent.trim() : null;
      if(alvo) alvo.click(); await w(400);
      o.paisEscolhido = S.pPais;
      o.listaFiltrada = listaPulsos().every(e => e.pais === S.pPais);
      S.pPais='todos';
      /* 15 · minha empresa */
      ir('minhaEmpresa'); await w(500);
      o.dezPilares = document.querySelectorAll('.pil_r, .pil__r, [class*="pil"]').length;
      o.temCamadas = document.body.innerText.indexOf('Where the pressure comes from') > -1;
      o.semBotaoVer = document.body.innerText.indexOf('Ver os dez pilares e de onde vem a pressão') === -1;
      o.voltarNoFim = (() => { const bs = Array.from(document.querySelectorAll('button')).filter(x=>x.textContent.indexOf('World Pulses')>-1);
        if(!bs.length) return false; const y = bs[0].getBoundingClientRect().top;
        const meio = document.body.scrollHeight/2; return bs[0].offsetTop > meio; })();
      /* 16 · o menu */
      S.menuConta = true; render(); await w(300);
      o.itensMenu = Array.from(document.querySelectorAll('.mc__t')).map(x=>x.textContent);
      S.menuConta = false;
      /* 17 · políticas */
      ir('politicas'); await w(500);
      o.pi = document.body.innerText.indexOf('Intellectual property') > -1;
      o.copyright = document.body.innerText.indexOf('Todos os direitos reservados') > -1 ||
        (POL.find(x=>x[0]==='Intellectual property')||[])[1].indexOf('Todos os direitos reservados') > -1;
      return o;
    });
    T('13 · o ressoar diz o que fazer', r.ressoar && r.novidades);
    T('14 · o recorte tem "Choose country" ('+r.filtros.join(' · ')+')', r.temEscolherPais);
    T('14 · o seletor lista países com pulso ('+r.paisesListados+')', r.paisesListados > 0);
    T('14 · e escolher um filtra a lista ('+r.paisEscolhido+')', r.paisEscolhido && r.paisEscolhido !== 'todos' && r.listaFiltrada);
    T('15 · a minha empresa mostra os dez pilares e as camadas', r.temCamadas && r.semBotaoVer);
    T('15 · com o voltar no fim da tela', r.voltarNoFim);
    T('16 · o menu tem quatro itens ('+r.itensMenu.join(' · ')+')', r.itensMenu.length === 4 &&
      r.itensMenu.join(' ').indexOf('Language') === -1 && r.itensMenu.join(' ').indexOf('anonimato') === -1 &&
      r.itensMenu.join(' ').indexOf('Subscriptions') > -1 && r.itensMenu.join(' ').indexOf('Suporte') > -1);
    T('17 · as políticas têm propriedade intelectual e copyright', r.pi && r.copyright);
    
  }

  /* ---- bloco 4 · a celebração e a pesquisa ---- */
  {
    const p = await nova();
    const r = await p.evaluate(async () => {
      const w=ms=>new Promise(r=>setTimeout(r,ms));
      S._boot=false; S.perfil={relacao:2,cargo:2,tamanho:3};
      QUESTIONS.forEach(q=>S.respostas[q.id]=40);
      S.result=calcular(); S.pago=true; liberaConta();
      ir('pesquisa'); await w(500);
      const o = {};
      const lil = document.querySelector('.lil');
      o.lilás = lil ? { txt:lil.textContent, cor:getComputedStyle(lil).color, italico:getComputedStyle(lil).fontStyle } : null;
      o.semCaixaAntes = !document.getElementById('pesqTx');
      const est = document.querySelector('.est');
      o.tamanhoEstrela = est ? Math.round(est.querySelector('svg').getBoundingClientRect().width) : 0;
      o.rotulo = (document.querySelector('.ests__r')||{}).textContent;
      /* escolhe 4 estrelas */
      document.querySelectorAll('.est')[3].click(); await w(400);
      o.nota = S.pesqNota;
      o.caixaDepois = !!document.getElementById('pesqTx');
      o.rotuloDepois = (document.querySelector('.ests__r')||{}).textContent;
      const ta = document.getElementById('pesqTx');
      o.fonte = ta ? { fam:getComputedStyle(ta).fontFamily.split(',')[0], tam:getComputedStyle(ta).fontSize } : null;
      /* escreve e muda a nota: o texto não pode se perder */
      ta.value = 'ajudou muito';
      document.querySelectorAll('.est')[4].click(); await w(400);
      o.textoPreservado = (document.getElementById('pesqTx')||{}).value;
      o.notaFinal = S.pesqNota;
      return o;
    });
    T('a palavra "clareza" está no lilás e sem itálico ('+r.lilás.cor+', '+r.lilás.italico+')',
      r.lilás.txt === 'clarity' && r.lilás.italico === 'normal' && r.lilás.cor !== 'rgb(0, 0, 0)');
    T('as estrelas ficaram maiores ('+r.tamanhoEstrela+'px)', r.tamanhoEstrela >= 44);
    T('a caixa só aparece depois da nota', r.semCaixaAntes && r.caixaDepois);
    T('o rótulo acompanha a nota ("'+r.rotulo+'" → "'+r.rotuloDepois+'")',
      r.rotulo === 'Tap a star' && r.rotuloDepois === 'Bastante');
    T('a caixa usa a fonte do Signal ('+r.fonte.fam+' '+r.fonte.tam+')', r.fonte.fam.indexOf('Instrument') > -1 || r.fonte.fam.indexOf('Inter') > -1);
    T('trocar a nota não apaga o que foi escrito ("'+r.textoPreservado+'")', r.textoPreservado === 'ajudou muito' && r.notaFinal === 5);
    
  }

  console.log('\n===== os ajustes do M2: '+ok+' ok, '+falha+' falhas · erros de página: '+(erros.length?erros.slice(0,3):'nenhum')+' =====');
  await b.close();
  process.exit(falha ? 1 : 0);
})().catch(e => { console.error('ERRO:', e.message); process.exit(1); });
