/* a jornada inteira, do começo ao fim, pelos cliques */
const { chromium, devices } = require('playwright');
const path = require('path');
let ok=0, falha=0; const T=(n,c)=>{ if(c) ok++; else { falha++; console.log('FALHA:',n); } };
(async()=>{
  const b = await chromium.launch();
  const p = await (await b.newContext({ ...devices['iPhone 13'] })).newPage();
  const erros=[]; p.on('pageerror', e=>erros.push(e.message.slice(0,140)));
  await p.goto('file://'+path.resolve('/home/claude/w/signal_m2.html'),{waitUntil:'load'});
  await p.waitForTimeout(700);
  const r = await p.evaluate(async () => {
    const w = ms => new Promise(r=>setTimeout(r,ms));
    const o = {passos:[]};
    S._boot=false; ir('home'); await w(300);
    /* o questionário inteiro, respondendo pelas opções */
    A.comecar(); await w(400);
    let guarda = 0;
    while(S.rota === 'avaliar' && guarda++ < 40){
      const ops = document.querySelectorAll('.opt');
      if(!ops.length) break;
      ops[Math.min(1, ops.length-1)].click();
      await w(120);
    }
    o.passos.push('questionário: '+guarda+' respostas, rota '+S.rota);
    o.chegouNoEmail = S.rota === 'email';
    /* Google + termos */
    if(S.rota==='email'){
      document.querySelector('[data-a="googleOk"]').click(); await w(300);
      document.getElementById('termos').click(); await w(200);
      document.querySelector('[data-a="emailOk"]').click(); await w(3200);
    }
    o.chegouNoSinal = S.rota === 'sinal';
    /* libera e percorre */
    if(!S.result){ S.result = calcular(); }
    S.pago = true; liberaConta(); ir('pilares'); await w(400);
    ir('separar'); await w(400);
    o.separar = S.rota === 'separar';
    /* marca os três itens do pilar */
    document.querySelectorAll('[data-a="marcar"]').forEach((b2,i)=>{ if(i<3) b2.click(); });
    await w(300);
    o.marcou = Object.keys(S.sep).length > 0;
    /* vai direto ao fim */
    S.acoes=['x']; S.empresa='ACME'; S.empresaK=chaveEmp('ACME');
    /* build de 15/09: o sinal passou a carregar o país, escolhido no somar */
    S.paisSinal='Brazil';
    ir('somar'); await w(300); A.somarSinal(); await w(400);
    o.somou = !!S.somado;
    todasPerguntas(S.result).forEach(q => S.diario[q.id]='resposta');
    ir('resposta'); await w(400);
    const ta = document.getElementById('rtx'); if(ta) ta.value='minha resposta';
    A.guardarResp(); await w(3600);   /* a celebração dura ~3,1s */
    o.pesquisa = S.rota === 'pesquisa';
    A.pesqPular(); await w(400);
    o.fim = S.rota;
    o.menus = MENUS.map(m=>m.livre());
    /* todas as rotas abrem sem erro */
    for(const rota of Object.keys(R)){
      try { const html = R[rota](); if(typeof html !== 'string') o.passos.push('rota sem html: '+rota); }
      catch(e){ o.passos.push('ERRO em '+rota+': '+e.message.slice(0,60)); }
    }
    return o;
  });
  T('o questionário vai até o e-mail ('+r.passos[0]+')', r.chegouNoEmail);
  T('o Google e os termos levam ao sinal', r.chegouNoSinal);
  T('a separação abre e marca', r.separar && r.marcou);
  T('somar, responder e a pesquisa ('+r.fim+')', r.somou && r.pesquisa && r.fim === 'resposta');
  T('os cinco menus ficam abertos no fim', r.menus.every(Boolean));
  T('as 25 rotas renderizam sem erro', !r.passos.some(x=>x.indexOf('ERRO')>-1));
  r.passos.filter(x=>x.indexOf('ERRO')>-1).slice(0,3).forEach(x=>console.log('   '+x));
  console.log('\n===== jornada: '+ok+' ok, '+falha+' falhas · erros de página: '+(erros.length?erros.slice(0,3):'nenhum'));
  await b.close();
})();
