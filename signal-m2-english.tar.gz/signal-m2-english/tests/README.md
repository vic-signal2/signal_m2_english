# Tests

Four Playwright suites, **69 checks**, run against a file path passed as the
first argument.

```bash
npm install playwright
npx playwright install chromium

node tests/t_adjustments.js   signal_m2_en.html   # 32 checks
node tests/t_two_signals.js   signal_m2_en.html   #  6 checks
node tests/t_journey.js       signal_m2_en.html   #  6 checks
node tests/t_review_round.js  signal_m2_en.html   # 25 checks
```

Each prints a one-line summary and exits non-zero on failure.

| Suite | What it covers |
|---|---|
| `t_adjustments` | The screen-by-screen adjustments: home, paywall order, focus question above 5,000, counters, celebration, survey, journal, colours |
| `t_two_signals` | Creating a second signal, archiving the first, switching between them, and what each one keeps |
| `t_journey` | The full path from questionnaire to answer, including adding the signal |
| `t_review_round` | The resume band, the country of the signal, the account and subscriptions, the context band, the company selector |

## Writing tests here

Three rules learned the expensive way:

**Clear `localStorage` per block.** State leaks between scenarios otherwise.

**Re-query after every click that re-renders.** Element references go stale,
and a test holding a detached node silently does nothing.

**Compare text case-insensitively.** `innerText` returns text already
transformed by CSS, so a label rendered through `text-transform: uppercase`
comes back uppercase.

And one about intent: a test that calls `A.someAction()` by hand proves nothing
about the click. Global delegation passes the element as the second argument,
so the real path is clicking the element.
