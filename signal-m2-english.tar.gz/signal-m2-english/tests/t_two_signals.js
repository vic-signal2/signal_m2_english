/* dois sinais seguidos, pelo caminho real */
const { chromium, devices } = require('playwright');
const path = require('path');
let ok=0, falha=0; const T=(n,c)=>{ if(c) ok++; else { falha++; console.log('FALHA:',n); } };
(async()=>{
  const b = await chromium.launch();
  const p = await (await b.newContext({ ...devices['iPhone 13'] })).newPage();
  const erros=[]; p.on('pageerror', e=>erros.push(e.message.slice(0,120)));
  await p.goto('file://'+path.resolve(process.argv[2] || '/home/claude/w/signal_m2.html'),{waitUntil:'load'});
  await p.evaluate(()=>{ try{ localStorage.clear(); }catch(e){} });
  await p.reload({waitUntil:'load'}); await p.waitForTimeout(700);
  const r = await p.evaluate(async () => {
    const w = ms => new Promise(r=>setTimeout(r,ms));
    const o = {};
    const percorrer = async (nota) => {
      /* questionário pelos cliques */
      let g=0;
      while(S.rota==='avaliar' && g++<40){
        const ops = document.querySelectorAll('.opt');
        if(!ops.length) break;
        ops[Math.min(nota, ops.length-1)].click(); await w(90);
      }
      if(S.rota==='email'){
        /* no segundo sinal o e-mail já está conectado e os termos aceitos:
           a tela vem com o chip e só o botão de seguir */
        const g = document.querySelector('[data-a="googleOk"]');
        if(g){ g.click(); await w(250); }
        const tm = document.getElementById('termos');
        if(tm && !tm.checked){ tm.click(); await w(150); }
        document.querySelector('[data-a="emailOk"]').click(); await w(3100);
      }
      S.pago=true; liberaConta();
      todasPerguntas(S.result).forEach(q=>S.diario[q.id]='r');
      ir('resposta'); await w(400);
      document.getElementById('rtx').value='minha resposta';
      A.guardarResp(); await w(700);
      const cel = !!document.querySelector('.cel');
      await w(3000);
      return { celebrou:cel, rota:S.rota };
    };
    S._boot=false; ir('home'); await w(200); A.comecar(); await w(300);
    o.um = await percorrer(1);
    if(S.rota==='pesquisa'){ document.querySelectorAll('.est')[4].click(); await w(300); A.pesqEnviar(); await w(400); }
    o.notaDada = S.pesqNota;
    /* o segundo sinal, pelo botão de criar */
    A.criar(); await w(400);
    const bt = document.querySelector('[data-a="novoOk"]');
    if(bt) bt.click(); else A.novoOk();
    await w(500);
    o.rotaNovo = S.rota;
    o.dois = await percorrer(2);
    o.menus = {};
    MENUS.forEach(m => o.menus[m.r] = m.livre());
    return o;
  });
  T('o primeiro sinal celebra e abre a pesquisa ('+JSON.stringify(r.um)+')', r.um.celebrou && r.um.rota === 'pesquisa');
  T('a nota é registrada ('+r.notaDada+')', r.notaDada === 5);
  T('criar sinal leva ao questionário ('+r.rotaNovo+')', r.rotaNovo === 'avaliar');
  T('o segundo sinal TAMBÉM celebra ('+JSON.stringify(r.dois)+')', r.dois.celebrou);
  T('e vai direto à resposta, sem repetir a pesquisa', r.dois.rota === 'resposta');
  /* Pulsos fica fechado de propósito: neste percurso a pessoa nunca somou o
     sinal. O que se verifica é que os menus já conquistados não trancaram. */
  T('os menus conquistados seguem abertos ('+JSON.stringify(r.menus)+')',
    r.menus.sinal && r.menus.diario && r.menus.vozes && r.menus.ass && !r.menus.pulsos);
  console.log('\n===== dois sinais: '+ok+' ok, '+falha+' falhas · erros: '+(erros.length?erros.slice(0,2):'nenhum'));
  await b.close(); process.exit(falha?1:0);
})();
