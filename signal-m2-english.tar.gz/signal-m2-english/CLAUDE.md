# CLAUDE.md · how to work in this repository

*For any agent that opens this project.*

## The context in three sentences

The product is **Milestone 2**, in `signal_m2_en.html`, published at the root.
It is the **English build**, generated from the Portuguese master through the
maps in `translation/`. Portuguese is the master language: content decisions
are made there and flow into here.

## The golden rules

1. **The deterministic report is the heart and is never rebuilt.** Indicator
   calculation and text generation are executable specification. Evolving them
   is incremental; rewriting from scratch is forbidden.
2. **The database records, it does not replace.** It persists inputs and
   outputs with the corpus version. It never reimplements calculation or text.
3. **Portuguese is the master language.** Every word is born in pt-BR. To
   change what the product *says*, change the master and the map, not this
   file. To fix a *bad translation*, change the map and regenerate.
4. **The questionnaire is universal**: the same 25 questions for everyone. What
   changes per journey is the framing.
5. **Scope decides.** What was not decided was not decided: ask before building
   it.

## The writing standard

Simple, clear, concrete, anchored in the questions and in the technical
substance of each pillar. No vague analogies. **No em dashes.** The score is
written with the percent symbol: **"59%"**.

Two rules that came out of a full text review and still hold:

- **What is within reach is an action; what is not is a condition.** Every
  sentence in the "what is yours" column starts with a verb, because the person
  will mark "I can do this" or "Not right now". The column for what is not
  theirs describes conditions, with no command verb: suggesting an action there
  would hand back a weight that is not theirs to carry.
- **Drop the image, state the fact.** Hierarchy metaphors ("the pressure from
  above", "the people below") became direct description.

## How to touch the build

`signal_m2_en.html` is a single self-contained file with no server dependency.
The whole corpus is embedded in it.

- **Before changing text, confirm how it appears in the file**, not how it
  reads on screen: sentences with `<strong>` inside do not match the flat
  string, and some texts are assembled from more than one place in the code.
- **Every text has an address.** When applying a revision, use the key
  (`CORPUS.pilares.ordem.jornadas.A.alcance.dentro[1]`), never a search by
  fragment: that is what stops one text being swapped for another.
- **Verify on the device, not just in the function.** A test that calls the
  action by hand can pass while the real click fails: global delegation calls
  `ACTS[act](value, element)`, and the second argument is the element.
- **Before fixing a bug, prove the product is actually wrong.** Twice during
  the audit a "bug" turned out to be correct behaviour, and changing it would
  have broken a real gate.

## Technical traps

These cost real time and remain valid:

- **Never replace the `innerHTML` of a scrolled container** to reflect state.
  Safari defers the repaint: the screen stays blank until the person scrolls.
  Use reconciliation, changing only what changed.
- **A scroll anchor is the smallest block under the eyes**, never a large
  container.
- **When removing a block, look for whoever used it as an insertion anchor.**
- **Blocks that one layer creates and another removes are debt**: dismantle
  them at the source.
- **Printing:** a page box with a fixed height in mm only works with zero
  margins. Whoever saves through the browser uses the default margin, and every
  page overflows into a blank sheet behind it.
- **A re-render destroys the element references a test is holding.** Re-query
  after every click that redraws.
- **`innerText` returns text already transformed by CSS** (`text-transform:
  uppercase`), so compare case-insensitively in tests.
- **State leaks between test scenarios through `localStorage`**: clear it per
  block.

## Translation traps, specific to this repository

Read `docs/TRANSLATION.md` before changing any string. The short version:
route names, action names, pillar keys, state keys and journey letters are
**identifiers**, not text. Translating one of them breaks navigation or the
engine silently. Two real examples are recorded in `docs/AUDIT.md`.

## When delivering

1. Run every test that exists before publishing.
2. Record it in `CHANGELOG.md`, saying **what changed and why**, not just what.
3. Update the affected document. If a rule changed, it changes in
   `docs/RULES.md`.
4. If the change is a translation fix, update `translation/` too, or the next
   regeneration will undo it.

## What not to do

- Do not change the universal questionnaire or the calculation mechanics
  without an explicit request.
- Do not "improve" approved texts without a new request.
- Do not use real third-party data.
- Business rule changes: confirm first.
