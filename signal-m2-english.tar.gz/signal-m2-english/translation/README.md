# Translation maps

These two files generate the English build from the Portuguese master. See
[../docs/TRANSLATION.md](../docs/TRANSLATION.md) for the full pipeline.

| File | Entries | Applied to |
|---|---|---|
| `translation_map_pt_en.json` | 2,187 | Complete string literals, longest first |
| `translation_words_pt_en.json` | 100 | Words inside larger literals, in screen-text positions only |

**Editing English text directly in the HTML is a temporary fix.** The next
regeneration overwrites it. Change the map instead.

Never add an entry whose key is a route name, an action name, a pillar key, a
state key or a journey letter. Those are identifiers. `'sinal'` was added once
and broke nine navigations.
