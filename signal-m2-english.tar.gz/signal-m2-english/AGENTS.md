# AGENTS.md

This repository follows the working agreement in **[CLAUDE.md](CLAUDE.md)**.
Read it before making any change. It applies to every agent and every tool, not
only to Claude.

The short version:

- The deterministic core is never rewritten, only evolved.
- Portuguese is the master language; this is a generated English build.
- Route names, action names and data keys are identifiers, never text.
- Prove a bug before fixing it; run the suites before delivering.

Start here, in this order:

| Document | What it answers |
|---|---|
| [CLAUDE.md](CLAUDE.md) | How to work here, and what breaks if you do not |
| [docs/RULES.md](docs/RULES.md) | What the product does, and why |
| [docs/DETERMINISTIC_CORE.md](docs/DETERMINISTIC_CORE.md) | How answers become text |
| [docs/TRANSLATION.md](docs/TRANSLATION.md) | How this build is generated |
| [docs/AUDIT.md](docs/AUDIT.md) | What is verified, and how to verify it again |
| [docs/SCREENS_AND_FLOWS.md](docs/SCREENS_AND_FLOWS.md) | What screens exist and how they connect |
| [docs/DATA_MODEL.md](docs/DATA_MODEL.md) | What the backend stores |
| [docs/VISUAL_FIDELITY.md](docs/VISUAL_FIDELITY.md) | The closed design system |
