# Changelog

## Initial English build

The first complete English version of Signal Milestone 2, generated from the
Portuguese master and audited end to end.

### The translation

**2,187 complete texts** plus **100 words** inside larger literals: the whole
interface, the 930-text corpus of the Ten Pillars, the journal in its six
journeys, the policies, the downloadable report and the assistant.

The glossary is in `docs/TRANSLATION.md`. The decision worth naming is
**Íntegro → Whole**: "Integral" reads technical and "Sound" reads mechanical,
while "Whole" carries the wholeness the Integrity pillar rests on.

### Bugs found by the audit

**Every pillar reading was empty above 78.** The corpus band key `alto` had
been translated to `high` while the code still read `P.alto`. Anyone in a
Harmonic or Whole state received an empty string where the pillar reading
belonged. Nothing threw; the product simply said less to the people doing well.

**Nine navigations were broken by one word.** Translating the literal `'sinal'`
to give the downloaded report an English filename also rewrote nine
`ir('sinal')` calls into a route that does not exist. Reverted, and the
filename handled as a targeted patch. Every internal key set is now compared
against the Portuguese build.

**Ticking the terms box erased the typed email.** Typing an address and then
accepting the terms re-rendered the screen and cleared the field; the person
pressed continue and got "write a valid email address" while looking at the
address they had just typed, on the screen that decides conversion. Fixed here
by storing the value before the re-render. **The same bug exists in the
Portuguese master and should be fixed there.**

**Dates rendered as "17 of set".** A global replacement of `" de "` reached the
date formatter. Rewritten for English: `Sep 17, 11:15 PM`, with the `en-US`
locale.

**Portuguese surviving in rare paths.** Journey-specific layer labels, the
downloadable report's section titles, eight system notices, download filenames,
the assistant's opening line, "0 of 3 marked", "Create signal", "Pillar 1 of
3", two corpus lines and one shareable-image phrase.

### Deliberate divergences from the master

The crisis line points at the **988 Suicide & Crisis Lifeline** instead of the
Brazilian CVV 188 and SAMU 192. A phone number people cannot call is worse than
no number at all, and any other market needs its own.

Fictional sample company names with Portuguese names were localized. Names that
were already neutral were left alone.

### Verification

| | |
|---|---|
| Structure | 89 actions with handlers, 25 routes, 31 icons, nothing orphaned |
| Internal keys | identical to the Portuguese build |
| Corpus parity | 3,907 keys, same shape, no text lost or emptied |
| Click crawler | 471 buttons across 25 screens, zero blank screens |
| Combinations | 1,692 texts across 6 journeys × 6 states, zero empty or broken |
| Deterministic engine | 7 scenarios, zero divergences from Portuguese |
| Journey by clicks | 7 of 7, questionnaire through answer |
| Keyboard | the whole questionnaire, 20 answers |
| Artifacts | shareable PNG generated, report built in English |
| Assistant | opens, answers, respects the quota of 15 |
| Portuguese remaining | zero on screen, zero in data structures |
| Test suites | 69 checks, all green |

`docs/AUDIT.md` describes each check and how to run it again.
