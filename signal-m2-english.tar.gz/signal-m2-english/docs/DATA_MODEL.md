# Data model

*The database records, it does not replace (Golden Rule nº 2).*

The database stores **what the person answered** and **what the product
returned**, along with the corpus version that generated that text. It does
**not** reimplement calculation or text generation: those live in the
deterministic core, and the result is written as output.

Why that matters: if the corpus changes tomorrow, the report the person read
yesterday is still the report they read. Storing the version is what makes that
possible.

---

## The entities

### person
Email (unique, required), language, creation date, optional password, two
factor, terms acceptance with date.

**No name.** The product never asks for one.

### signal
A signal is one person's assessment of one company.

- person, company, **scope** (from the focus question: local team, business
  unit, country operation, global), country
- resolved journey (A · B · C · D · E · Z) and the profile answers
- the 20 answers, each with its statement and value (0 · 25 · 50 · 75 · 100)
- result: overall score, score per pillar, score per layer, state
- **the corpus version** that generated the texts
- status: in progress · processed · unlocked · added · withdrawn
- dates of creation, unlocking and adding

**Reassessing the same company** creates a new signal: the previous one leaves
the aggregates and becomes history in the person's list.

**The country belongs to the signal, not to the person.** Someone working in
one country may be assessing the operation of another.

### separation
Per signal: the up to three chosen pillars, and for each of them the three
items with their marking (`can_do` · `not_now`), plus the final chosen actions.

**No marking at all is also an answer**, and has to be distinguishable from
"has not reached this screen yet".

### journal
Per signal: the ten answers, each with its step, its question, the text, the
creation date and the edit date, plus the "edited" flag.

### answer
Per signal: the text, the first save date, and the rewrite history if any.

### company
Name, normalized key (case, accents and corporate suffixes stripped), country,
and the record of whether it was created by a person or came from the base.

### pulse
Not a stored entity so much as an aggregation over signals, by the pair
**company + scope**, respecting the time window and the declared/verified
filter. It exists from **two signals** onward.

Rows must never allow a single signal to be reconstructed.

### subscription
Type (one-off, monthly, annual), start, end, status, and the quotas consumed:
signals, assistant messages, podcasts. **No automatic renewal.**

### assistant conversation
Per signal: the messages, who sent them, timestamps, and the quota consumed.
Never included in the downloadable report.

---

## Retention

The server keeps everything indefinitely. The copy in the browser expires in
**7 days** and exists only so work in progress is not lost.

Deleting a signal removes it from history, from the company pulse and from the
index at the next aggregation.

---

## What the backend must not do

- Recompute a score, a state or a text. Those arrive as outputs.
- Store anything that identifies a person inside an aggregate.
- Publish a segment small enough to expose an individual.
- Change a corpus version retroactively on an existing result.
