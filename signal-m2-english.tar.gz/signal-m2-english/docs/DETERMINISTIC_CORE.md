# The deterministic core

*How to carry the heart of the product without breaking it · Milestone 2*

Given the same answers, the same text comes out. Always. This is the part of
Signal that **must not change its result** when ported to the real system, and
the part that a translation must leave numerically untouched.

---

## 1 · From answers to score

**20 statements**, two per pillar, on a five-point scale worth **0, 25, 50, 75
and 100**. Each statement carries two markers in `QUESTIONS`:

- `p` — the pillar it belongs to
- `l` — the layer: `org`, `lider` or `indiv`

**Pillar score** = the average of that pillar's two statements.
**Layer score** = the average of that layer's statements.
**Perceived harmony** = the overall average.

Neither the pillar nor the layer is revealed to the person during the
questionnaire.

---

## 2 · From score to state

| Band | State | Key (`k`) |
|---|---|---|
| 0 to 32 | Risk of Rupture | `ruptura` |
| 33 to 47 | Acute Crisis | `aguda` |
| 48 to 66 | Crisis | `crise` |
| 67 to 77 | Tension | `tensao` |
| 78 to 88 | Harmonic | `harmonico` |
| 89 to 100 | Whole | `integro` |

The cuts live in `STATES`, each with name, band and colour. **Never repeat a
loose number**: anything that needs "below Crisis" reads the threshold from the
scale.

**The `k` keys stay in Portuguese on purpose.** They are identifiers, not text.
See `TRANSLATION.md` for why this matters.

---

## 3 · From score to text: the three-step assembly rule

This is the central rule of Milestone 2, and it governs each pillar's text:

1. **89 or above** → uses the **Whole** text (`pillar.high.integro`).
2. **78 to 88** → uses the **Harmonic** text (`pillar.high.harmonico`), **with
   no cost line**.
3. **Below 78** → the text is the **opening of the lowest-scoring facet**
   (`severo` below 48, `moderado` above) **plus the cost of that facet for the
   person's journey**.

**Reach and labels always come from the journey**, in every band.

> In the English build the band key is `high`, where the Portuguese master has
> `alto`. The accessor in the code was changed to match. This pairing broke
> once during translation and produced empty pillar readings for every person
> in a Harmonic or Whole state; `AUDIT.md` describes how it was found.

---

## 4 · Where the corpus lives

Everything is embedded in `signal_m2_en.html`, under `CORPUS`
(`Signal_Corpus_v1_1`), with **930 texts**:

```
CORPUS.pilares.<pillar> = {
  nome, grupo, cor, posicao, essencia,
  facetas: [ { id, camada, pergunta, abertura: { severo, moderado } } ],
  high:    { harmonico, integro },
  jornadas: { A|B|C|D|E|Z: {
    rotulos: [ within, outside ],
    alcance: { dentro: [3], fora: [3] },
    custo:   { <facet>: { severo, moderado } },
    reserva: { severo, moderado }
  } }
}
```

The count, which matches the scope:

| | |
|---|---|
| Pillar essence | 10 |
| Questionnaire statements | 20 |
| Facet openings, severe and moderate | 40 |
| High-band texts | 20 |
| Journey labels | 120 |
| Reach, within | 180 |
| Reach, outside | 180 |
| Costs per journey | 240 |
| Reserves | 120 |
| **Total** | **930** |

Alongside it: `DIARIO` (v7.1, 10 questions × 6 journeys), `SINAL` (36 present
tense questions plus 36 in the past tense, 8 layer patterns, labels), `ARTE`,
`QUESTIONS`, `PERFIL`, `POL`, `PULSOS`, `VOZES`, `PAINEIS`, `MENUS`, `STATES`,
`GRUPOS`, `GEO10`, `DIM_RISCO`, `AGREE`, `PAISES`.

---

## 5 · The lookup tables that must agree

Four structures are indexed by the value of another structure. If one side is
renamed and the other is not, the product silently prints `undefined`:

| Table | Indexed by |
|---|---|
| `SEV` | `STATES[].n`, the state name |
| `DIM_RISCO` | the short group name, after stripping the `Pillars of ` prefix |
| `GRUPOS` | the prefix consumed by that `replace` |
| `CORPUS.pilares.<p>.high` | the literal accessor in `leituraPilar` |

Any change to a state name, a group name or a band key has to move both sides
in the same commit. `tests/` covers this; so does the key audit described in
`AUDIT.md`.

---

## 6 · Porting rules

**The database records, it does not replace.** Persist inputs (the answers) and
outputs (results, generated texts, corpus version). Do not reimplement the
calculation or the text assembly on the server: if the two ever disagree, there
is no way to know which one is right.

**Store the corpus version with every result.** `CORPUS.versao` exists for
this: a text regenerated a year later must be traceable to the corpus that
produced it.

**Do not round differently.** The averages are plain arithmetic means; the
state comes from integer band comparison. Any difference in rounding moves
people between states.
