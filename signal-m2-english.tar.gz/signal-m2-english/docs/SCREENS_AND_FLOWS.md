# Signal · Screens and flows

*An inventory of what exists in this build and how it connects.*

Verified against `signal_m2_en.html`.

---

## The routes

The build has **25 routes**, in its own router (`ir(route)`), rendering into
`#app`:

`home · politicas · avaliar · email · apurando · sala · sinal · pilares ·
separar · pilarExtra · acoes · somar · convite · meio · diario · saiu ·
resposta · celebra · pesquisa · ass · pulsos · pulsoDet · minhaEmpresa ·
vozes · conta · assinatura`

**Route names are identifiers and stay in Portuguese.** They are never shown to
anyone. See `TRANSLATION.md`.

Three routes run **without the navigation shell**: `apurando`, `home` and
`email`.

Screens that are sub-flows light up the menu they belong to, through `MENU_DE`:
the answer lights Journal, the separation lights Signal, My Company lights
Pulses.

---

## The main path

```
home → avaliar (25 questions) → email → apurando → sinal
  → [pay] → pilares → separar (3 pillars × 3 items) → acoes
  → somar → convite → meio
  → diario (5 steps, 10 questions) → resposta → celebra → pesquisa
```

From `meio` ("First part done"), "Come back later" leads to My signal, with the
way back always visible.

---

## 1 · Home

Three panels chained by "Read more", each the height of the window, with no
scrolling. The texts live in `PAINEIS`:

1. **The noise** — "Do you feel something is out of tune at work? It might be a signal."
2. **The inversion** — "For the first time, no one knows how to explain the world to anyone."
3. **Your signal** — "You are not the noise. Understand what you perceive and find your signal."

The **"Room"** opening runs before it: dissonant lines in the dark converge,
the brand is revealed, and a front of light sweeps from the left. It plays
**once per browser** and respects `prefers-reduced-motion`. **It does not
change.**

Full sign-in (Google, email link, recovery, two-factor), a social counter with
the real number of signals, and a minimal footer with "Privacy and terms". The
home also carries "I already have an account. Sign in".

## 2 · Assess

An elevated white card, no transition between questions, a signal rail 8 to
10 px tall, keys 1 to 6, Enter, and automatic advance.

Profile in four conditional questions (`PERFIL`), the focus question for large
companies, and the **20 statements** (`QUESTIONS`), each carrying its pillar
and layer, on a five-point scale.

## 3 · Email and processing

Email is required, on both paths, with acceptance of the terms. The typed
address survives ticking the terms box. `apurando` is a short animated screen
that ends on the signal.

## 4 · Signal

The score, the state, the scale with the marker positioned proportionally, the
three layers, and the question that is probably on the person's mind. Below the
veil, a blurred preview of the Ten Pillars with real numbers.

Once paid, two shortcut cards: the separation, then the journal. A **resume
band** appears whenever the person stopped somewhere, in this order:
interrupted separation → interrupted journal → the answer is missing → the
signal was never added.

## 5 · Pillars, separation and actions

Ten pillars ordered from most strained to strongest, grouped in Action,
Structure and Cohesion. The separation takes at most three pillars, one at a
time, three items each, marked as "I can do this" or "Not right now". Extra
pillars can be opened through `pilarExtra`, which is read-only when the pillar
is not in tension.

The actions screen asks for three choices, and accepts "nothing marked" as a
legitimate answer.

## 6 · Add and invite

`somar` identifies the company, asks for the **country of the signal**, and
adds the signal anonymously. Without a country the add button does not appear:
a pulse with no country is data no one can use.

`convite` confirms the signal joined the pulse and offers the invitation.

## 7 · Journal and answer

Five steps, ten questions, one at a time, with a sequential gate at both
levels. Drafts save automatically. With more than one signal, a bar names the
active signal's company and date.

`resposta` closes the exercise, showing the question in the past tense and the
ten journal answers collapsed by step. It carries a context band naming where
the person is and how to go back.

`celebra` is a layer, not a route destination, and happens on every completed
signal. `pesquisa` is the satisfaction survey, once per account.

## 8 · Pulses, My Company and Voices

`pulsos` lists companies with a pulse, with filters for scope, time window,
declared or verified voices, and country, each with its flag. `pulsoDet` opens
one company. `minhaEmpresa` shows the pulse of the company the person assessed,
or, when that company has no pulse yet, says so plainly rather than showing
another company's numbers.

`vozes` lists subjects by country, with resonate and receive-updates, and
proposing a subject requires its country.

## 9 · Account and subscriptions

`conta` holds profile and access, privacy shortcuts, the person's signals, and
the sensitive area. `assinatura` has its own screen: what you have, until when
it is valid, and what happens if you do not renew. Nothing is purchased without
confirmation.

The avatar in the top right carries the person's initial and opens the account.
