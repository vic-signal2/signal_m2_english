# Visual fidelity

*The aesthetic of the system has to be exactly the one in this build.*

## The principle

Signal's design is not an "approximate style": it is a closed set of decisions
that were already made, tested on a device and approved. The work of anyone
porting it is **extraction and transfer**, never recreation. If a component
ends up "similar but not identical", it is wrong.

The source of visual truth is the CSS inside the build itself. Practical rule:
**copy the CSS out of the file** (as global CSS, CSS modules, or
styled-components generated from it) rather than rewriting from memory or
"translating it to Tailwind". Translating into another styling vocabulary is
where fidelity dies.

---

## Tokens (the palette is closed)

| group | tokens |
|---|---|
| surfaces | `--paper #FCFCFE`, `--paper-2 #F7F6FC`, `--mist #F4F1FD` |
| ink | `--ink #14121C`, `--ink-70 #3A3648`, `--slate #6C6880`, `--slate-40 #A5A1B5` |
| lines | `--line #E8E5F3`, `--line-soft #F0EEF9` |
| brand | `--violet #6B4ED8`, `--violet-dark #523BAE`, `--lilac #AD92F0`, `--lilac-soft #D8CCF8` |
| traffic light | `--calm #3E9E86`, `--warm #D9962F`, `--hot #D2565A` |
| pillar groups | `--acao #E07A55`, `--estrutura #3E82A8`, `--coesao #7C5CE6` |
| radii | `--r-sm 8px`, `--r-md 14px`, `--r-lg 22px`, `--r-xl 30px` |
| shadows | `--shadow-1`, `--shadow-2` |

No colour outside these tokens and the official pillar and state colours may
enter the system. If something needs a colour that is not here, it is drawing
something this build does not draw.

---

## Typography (four families, fixed roles)

- `--f-display: 'Instrument Serif', Georgia, serif` — headlines; the serif
  italic is a brand signature.
- `--f-body: 'Inter', ...` — all running text.
- `--f-mark: 'Poppins', ...` — the "signal" wordmark.
- `--f-mono: 'IBM Plex Mono', ...` — eyebrows, counters and small caps labels
  with wide letter spacing.

Fonts are **embedded in the HTML as base64 woff**, which is why the file works
offline and why it is 705 KB.

---

## Rules that are easy to get wrong

**The score is written with the percent symbol**: "59%", with the number
dominant and the symbol small.

**The mid point of the scale is amber**, closing the sequence green → amber →
red. It is not violet.

**Marking buttons carry a lilac border.** White at 20% opacity did not read as
a button.

**The full stop belongs inside the lilac** in "One signal is a *voice.* Many
signals are a *pulse.*" The period is part of the emphasis, not after it.

**The hamburger is an avatar** carrying the person's initial, because that is
the system-wide pattern people already know.

---

## Mobile, which is 95% of use

The reference viewport is an iPhone 13. Anything that only works on a desktop
window is not done.

Safe areas matter: the page draws edge to edge under translucent system bars.
Use `viewport-fit=cover` plus `env(safe-area-inset-*)` padding, and size
full-screen layouts with `height: 100%` rather than `100vh`.
