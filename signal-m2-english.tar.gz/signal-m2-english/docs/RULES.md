# Signal · Business rules

*Source of truth for product behaviour · Milestone 2 · English build*

These are the rules of the product as built. They come from the Milestone 2
scope document, which is the record of decisions: **what is not there was not
decided**.

---

## §01 · Anonymity is the central promise

No individual answer appears on any screen, in any aggregate, for anyone. A
company's pulse shows averages and counts, never a signal.

**Segments are not shown** in Pulses, because of exposure risk.

A signal only leaves the aggregate at the request of the person who sent it.

---

## §02 · Journeys

Six of them, assigned by **declared work**, not by company size:

| | Journey | Who it is |
|---|---|---|
| A | Owner or co-founder | founded it, is a partner or the owner |
| B | Leadership with a team | leads an area or team, with people reporting |
| C | Team | coordination, analysis, specialist |
| D | Operations | plant, field, warehouse |
| E | Service provider | serves the company as a client |
| Z | Investor | has capital in the company |

The profile comes from **four conditional questions**: relationship with the
company · the role that describes the work · whether a team reports to them ·
size in five bands.

---

## §03 · The questionnaire

**25 questions, about three minutes.** The counter stays fixed at 25 from the
first question; whatever does not apply to the person's path fills itself in.

**The focus question** is conditional and appears only for companies **above
5,000 people**, right after size. The order runs from narrowest to broadest:
local team · business unit in my country · operation in the country · the
company as a whole. **"The company as a whole" feeds the Global pulse**; the
others add to the country pulse.

**The 20 pillar statements**, two per pillar, on a five-point scale worth
**0, 25, 50, 75 and 100**. Neither the pillar nor the layer is revealed.

**Email is required** between the last question and the result, with acceptance
of the terms, on both paths (Google and typed email). Email only, no name.

**A resume notice** appears when an assessment is already in progress.

---

## §04 · The six states

| Band | State |
|---|---|
| 0 to 32 | Risk of Rupture |
| 33 to 47 | Acute Crisis |
| 48 to 66 | Crisis |
| 67 to 77 | Tension |
| 78 to 88 | Harmonic |
| 89 to 100 | Whole |

The score is written with the **percent symbol**: "59%".

---

## §05 · What is free and what is paid

**Free:** the score, the state, the scale, the support block, the layers, and
the question that is on the person's mind.

**Paid:** everything else. The veil covers a blurred preview of the Ten Pillars
showing the real numbers, and the card over it does not show a price: it shows
what gets unlocked.

---

## §06 · Crisis support

With a score **below 34**, the support block appears, collapsed behind a
button, with the crisis line, the sentence about not deciding before being
well, and the scope notice. **The same threshold governs whether the assistant
mentions the crisis line.**

> **Localization note.** The Portuguese master carries the Brazilian lines
> (CVV 188 and SAMU 192). This build carries the **988 Suicide & Crisis
> Lifeline**, for the United States. Any other market needs its own line: this
> is content that must never be left pointing at a number people cannot call.

---

## §07 · Prices, quotas and access

| | One-off | Monthly | Annual |
|---|---|---|---|
| Price | US$ 4.90 | US$ 6.90/mo, **US$ 2.00 for the first** | US$ 42.00/yr |
| Signals | 1 | 2 per month | up to 25 per year |
| Assistant messages | 15 | 50 per month | 50 per month |
| Podcast | one-off, US$ 2.00 | 1 per month | 1 per month |

**Add-ons:** extra signal US$ 4.90 · 30 messages US$ 4.90 · podcast US$ 2.00.
A coupon applies a percentage discount.

**No automatic renewal on any plan.** The product vocabulary is
**subscription**, not "plan", and it has its own screen showing the term.
**No purchase happens without confirmation.**

**No referral-for-discount block.** Inviting friends exists, and it does not
pay.

### Access
Without a subscription, each one-off signal stays accessible for **30 days from
purchase**. With an active subscription everything is unlocked, **including
expired one-offs**. When the subscription ends, one-offs revert to their own
window.

---

## §08 · Data retention

**The server keeps everything indefinitely.** The local copy on the device
**expires in 7 days** and exists only so work in progress is not lost.

**Deleting a signal** requires double confirmation: it leaves the history, the
company's pulse and the index at the next aggregation.

---

## §09 · The pulse

**A pulse appears from two signals onward**, with a score.

The unit of a pulse is the pair **company + scope**: focus options 1 and 2 add
to the country pulse; "the company as a whole" creates the **Global** pulse.

**Declared voices and verified voices** are distinct filters, with **declared
as the default**. Every signal is born declared, and verification is a back-end
routine, invisible to the person.

**Time window** for signals: 1 week, 1 month, 6 months, 1 year, all time.
**1 year is the default.** **No signal ever expires.**

**Reassessing the same company** replaces the previous signal in the
aggregates; the old one becomes history in the person's list.

**Withdrawing the signal** exists in My Company and in Add, with a notice that
it closes access to Pulses.

**Adding your signal is the key to World Pulses.**

### The country of the signal
Chosen **when adding the signal**, from a base of 31 countries with code, dial
code, flag and continent. It belongs to the **signal**, not to the person:
someone working in one country may be assessing the operation of another.
Without a country there is no way to add.

### Company identification
Autocomplete that searches the base, ignores case, accents and corporate
suffixes, and **asks for confirmation before creating a new record**.

### Anti-fraud
A burst of positive signals in a short interval goes to **quarantine** before
counting.

---

## §10 · Menu unlocking

Five fixed menus, always visible, including during the exercises. What changes
is the lock.

| Menu | Opens when |
|---|---|
| Signal | the questionnaire is finished |
| Journal | the report is unlocked |
| Pulses | the signal has been added |
| Voices | the answer is written |
| Account | always |

**Unlocking belongs to the account, not to the current signal.** What opened
once stays open while the account is active: 30 days for a one-off, the
duration of the subscription when there is one. Creating a new signal does not
re-lock what was already opened.

**Create signal** sits on the right, always visible, with three gates:
assessment in progress, previous report not unlocked, plan limit reached. Plus
a confirmation before starting.

---

## §11 · The separation

At most **three pillars**, the lowest scoring ones **below 67**, with ties
broken in this order: Integrity, Self-responsibility, Purpose, Order,
Responsibility, Knowledge, Change, Communication, Service, Collaboration. If
none is below 67, **only the lowest one** enters.

One pillar at a time, with **three mandatory items** before advancing.

On the actions screen: if the person marked more than three items, they choose
three. **If they marked nothing, the screen recognizes that as a legitimate
answer** and allows them to finish.

---

## §12 · The journal

**Five steps and ten questions**, varying across the six journeys:

| | Step | Questions |
|---|---|---|
| 1 | The why | why it still matters · what weighs for and against |
| 2 | Boundaries | what no longer holds and what limits to set |
| 3 | Horizons | for how long · risks · paths · who to count on |
| 4 | Goals | three goals · which one changes the game |
| 5 | Decision | the decision that fits today |

**Sequential gate at both levels:** questions come in order within a step, and
the next step opens when the previous one closes. **Editing is not skipping.**

**Editing is always possible**, including after the answer, with an "edited"
mark.

The draft saves automatically.

**With more than one signal**, the journal is always the one of the **active
signal**, and a bar names the company and the date, with the switch beside it.

---

## §13 · The answer

It closes the exercise. On first save, the screen darkens for about three
seconds and acknowledges what the person did.

**The celebration is per signal:** every completed journey has one, always.

**The satisfaction survey is per account:** how much Signal helped the person
gain clarity, in five stars, with an optional field and the option to skip. It
appears after the celebration **the first time only**, and does not return on
later signals.

Someone who merely edits an existing answer sees neither. Before answering, the
person sees the **question in the past tense** and the ten journal answers
collapsed by step.

After answering, these unlock in order: **My Company, World Pulses and
Voices**, each respecting its own conditions.

**Rewriting the answer** reopens the field with the previous text.

---

## §14 · The downloadable report

An **HTML file with print styling**, generated at the moment of download, with
the current state of the journal. Eight numbered sections: cover · the reading
in one sentence · where the pressure comes from · the ten pillars · the
conclusion of the diagnosis · what to watch in this organization · what is
within my reach · the journal and the answer.

**Left out:** the company pulse and any third-party data, the conversation with
the assistant, and the shareable image.

---

## §15 · The assistant

A side drawer. **It only exists once the report is unlocked.**

**It appears** in My signal, Ten Pillars, Separate, Add, First part done,
Journal and Answer. **It does not appear** on the home, the questionnaire, the
email screen, payment, Voices, Pulses, Account and policies.

**On opening** it declares what it knows (company, score, state, open pillar or
step) and offers three suggestions. No greeting by name.

**Limits:** it speaks about the portrait and not about the world; it gives no
diagnosis and no prescription; it does not decide for the person; it mentions
the crisis line below 34; it does not judge named people.

**Quota:** 15 on the one-off, 50 per month on a subscription, plus 30 for
US$ 4.90. When it runs out, the conversation stays readable and only the input
closes.

**Fixed footer notice:** "The assistant is software and can be wrong. It is not
a diagnosis or health care."

---

## §16 · Voices

Subjects by country, with a filter of at most four chips and a panel with
search and continents.

Each subject has two actions: **resonate**, with a counter, and **receive
updates**. Sorted by most resonated.

**Proposing a subject** is always a submission for Signal review, **never
direct creation**, and requires the **country of the subject**: that is what
makes the filter work. Subjects come from Vocalis curation plus approved
proposals.

---

## §17 · Product scope and limits

Short scope notices appear **where the risk exists**: in the crisis support
block, in the assistant footer, in Add, and in the downloadable report.

The "Privacy and terms" page has five collapsible sections: Your data and
anonymity · Scope limits · **Intellectual property** · Terms and entity ·
Letter of principles.

**Intellectual property is explicit:** the Ten Pillars of Harmony™, the
methodology, the instrument, the texts and the Signal material are the property
of **Victor B. Costa and Vocalis Consulting**, protected by copyright, with
copying, reproduction, translation, adaptation, distribution, model training
and incorporation into another product forbidden without written authorization.
© 2026, all rights reserved.

Contact: **contact@sendsignal.live**

**The B2B part is switched off.**

---

## Open items

These were recorded in the scope document as pending and **must not be built
without a decision**: referral link, initial visibility of new subjects,
companies with no verified voices, granularity of the social counter, the
signal wave as a signature, which languages ship, legal review of the terms.
